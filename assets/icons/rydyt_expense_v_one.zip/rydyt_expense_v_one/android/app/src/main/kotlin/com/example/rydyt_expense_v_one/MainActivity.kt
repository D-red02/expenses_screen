package com.example.rydyt_expense_v_one

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
